import giftIcon from "@assets/generated_images/Red_gift_box_emoji_5a0f469c.png";
import partyIcon from "@assets/generated_images/Red_party_celebration_emoji_b590881b.png";
import pinIcon from "@assets/generated_images/Red_pin_emoji_b2481bf6.png";
import chartIcon from "@assets/generated_images/Red_analytics_chart_emoji_29852781.png";
import shieldIcon from "@assets/generated_images/Red_shield_emoji_5b715827.png";
import lightningIcon from "@assets/generated_images/Red_lightning_bolt_emoji_6e3eac1b.png";

export default function FeaturesSection() {
  const features = [
    {
      icon: giftIcon,
      title: "Chat Rewards",
      description: "Automatically reward active members with points, roles, or custom prizes for engaging in chat conversations."
    },
    {
      icon: partyIcon,
      title: "Giveaways",
      description: "Create exciting giveaways with custom entry requirements, multiple winners, and automatic prize distribution."
    },
    {
      icon: pinIcon,
      title: "Stickied Messages",
      description: "Keep important announcements visible with smart stickied messages that auto-refresh and stay on top."
    },
    {
      icon: chartIcon,
      title: "Advanced Logs",
      description: "Comprehensive logging system that tracks member activity, moderation actions, and server events with detailed analytics."
    },
    {
      icon: shieldIcon,
      title: "Moderation Tools",
      description: "Powerful moderation features with auto-moderation, warning systems, and customizable punishment workflows."
    },
    {
      icon: lightningIcon,
      title: "Lightning Fast",
      description: "Built for performance with 99.9% uptime, instant command responses, and reliable real-time processing."
    }
  ];

  return (
    <section id="features" className="py-20 px-6">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Powerful Features
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Everything you need to create an engaging and rewarding Discord community experience.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index}
              className={`bg-card border border-border rounded-2xl p-8 hover:bg-muted/50 transition-all duration-500 hover:scale-105 hover:shadow-xl group transform hover:-translate-y-2 ${
                index % 2 === 0 ? 'animate-slide-in-left' : 'animate-slide-in-right'
              }`}
              style={{ animationDelay: `${index * 0.1}s` }}
              data-testid={`feature-card-${index}`}
            >
              <div className="mb-4 group-hover:scale-110 transition-transform duration-500">
                <img 
                  src={feature.icon} 
                  alt={`${feature.title} icon`} 
                  className="w-12 h-12 mx-auto filter hover:brightness-110 transition-all duration-500 group-hover:rotate-12"
                />
              </div>
              <h3 className="text-2xl font-bold mb-4 text-card-foreground">
                {feature.title}
              </h3>
              <p className="text-muted-foreground text-lg leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
