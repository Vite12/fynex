export default function AboutSection() {
  const stats = [
    { value: "99.9%", label: "Uptime Guarantee", testId: "stat-uptime" },
    { value: "20+", label: "Powerful Commands", testId: "stat-commands" },
    { value: "24/7", label: "Community Support", testId: "stat-support" }
  ];

  const highlights = [
    {
      icon: "✨",
      title: "Intelligent Automation",
      description: "Smart systems that learn and adapt to your community's behavior patterns."
    },
    {
      icon: "🎯",
      title: "Targeted Engagement",
      description: "Customizable reward systems that motivate the right behaviors."
    },
    {
      icon: "📈",
      title: "Growth Analytics",
      description: "Detailed insights into your community's growth and engagement metrics."
    },
    {
      icon: "🔧",
      title: "Easy Setup",
      description: "Get started in minutes with our intuitive configuration system."
    }
  ];

  return (
    <section id="about" className="py-20 px-6 bg-muted/20">
      <div className="container mx-auto">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-8 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            Why Choose Fynex?
          </h2>
          
          <p className="text-xl text-muted-foreground mb-12 leading-relaxed">
            Built with love for Discord communities, Fynex brings powerful automation and engagement tools right to your server. Whether you're running a small community or managing a large server, Fynex adapts to your needs.
          </p>
          
          <div className="grid md:grid-cols-3 gap-8 mb-12">
            {stats.map((stat, index) => (
              <div 
                key={index} 
                className="text-center animate-scale-in transform hover:scale-110 transition-transform duration-300"
                style={{ animationDelay: `${index * 0.2}s` }}
              >
                <div 
                  className="text-3xl font-bold text-primary mb-2 hover:text-secondary transition-colors duration-300" 
                  data-testid={stat.testId}
                >
                  {stat.value}
                </div>
                <p className="text-muted-foreground">{stat.label}</p>
              </div>
            ))}
          </div>
          
          <div className="bg-card border border-border rounded-2xl p-8 text-left animate-slide-up hover:shadow-2xl transition-shadow duration-500">
            <h3 className="text-2xl font-bold mb-6 text-center text-card-foreground">
              What Makes Fynex Special?
            </h3>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-4">
                {highlights.slice(0, 2).map((highlight, index) => (
                  <div key={index} className="flex items-start space-x-3">
                    <span className="text-primary text-xl">{highlight.icon}</span>
                    <div>
                      <h4 className="font-semibold text-card-foreground">
                        {highlight.title}
                      </h4>
                      <p className="text-muted-foreground">
                        {highlight.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
              <div className="space-y-4">
                {highlights.slice(2).map((highlight, index) => (
                  <div key={index + 2} className="flex items-start space-x-3">
                    <span className="text-accent text-xl">{highlight.icon}</span>
                    <div>
                      <h4 className="font-semibold text-card-foreground">
                        {highlight.title}
                      </h4>
                      <p className="text-muted-foreground">
                        {highlight.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
