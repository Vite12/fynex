import { Button } from "@/components/ui/button";
import fynexLogo from "@assets/white-Photoroom-Photoroom_1757495187403.webp";

export default function Footer() {
  const handleJoinSupport = () => {
    // TODO: Replace with actual Discord support server invite
    const DISCORD_SUPPORT_SERVER_URL = 'https://discord.gg/YOUR_SUPPORT_SERVER';
    window.open(DISCORD_SUPPORT_SERVER_URL, '_blank');
  };

  return (
    <footer id="support" className="bg-card border-t border-border py-12 px-6">
      <div className="container mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center space-x-3 mb-6 md:mb-0">
            <img 
              src={fynexLogo} 
              alt="Fynex Logo" 
              className="w-8 h-8 rounded-xl"
              data-testid="logo-footer"
            />
            <div>
              <h3 className="font-bold text-card-foreground">Fynex</h3>
              <p className="text-xs text-muted-foreground">Discord Bot</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-6">
            <a 
              href="/privacy" 
              className="text-muted-foreground hover:text-primary transition-colors"
              data-testid="link-privacy"
            >
              Privacy Policy
            </a>
            <a 
              href="/terms" 
              className="text-muted-foreground hover:text-primary transition-colors"
              data-testid="link-terms"
            >
              Terms of Service
            </a>
            <Button
              onClick={handleJoinSupport}
              variant="ghost"
              className="text-muted-foreground hover:text-secondary transition-colors font-semibold"
              data-testid="button-support-footer"
            >
              Support Server
            </Button>
          </div>
        </div>
        
        <div className="mt-8 pt-8 border-t border-border text-center">
          <p className="text-muted-foreground">
            © 2024 Fynex. Made with ❤️ for the Discord community.
          </p>
        </div>
      </div>
    </footer>
  );
}
