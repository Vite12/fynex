import { Button } from "@/components/ui/button";

export default function CTASection() {
  const handleInviteBot = () => {
    // TODO: Replace with actual Discord bot invite link with proper permissions
    const DISCORD_BOT_INVITE_URL = 'https://discord.com/api/oauth2/authorize?client_id=YOUR_BOT_ID&permissions=YOUR_PERMISSIONS&scope=bot%20applications.commands';
    window.open(DISCORD_BOT_INVITE_URL, '_blank');
  };

  const handleJoinSupport = () => {
    // TODO: Replace with actual Discord support server invite
    const DISCORD_SUPPORT_SERVER_URL = 'https://discord.gg/YOUR_SUPPORT_SERVER';
    window.open(DISCORD_SUPPORT_SERVER_URL, '_blank');
  };

  return (
    <section className="py-20 px-6">
      <div className="container mx-auto text-center">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
            Ready to Transform Your Server?
          </h2>
          <p className="text-xl text-muted-foreground mb-12">
            Ready to enhance your Discord server? Add Fynex today and start building a more engaging community with automated rewards and fun giveaways.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
            <Button 
              onClick={handleInviteBot}
              className="px-10 py-5 hero-gradient text-white font-bold text-xl rounded-xl hover:shadow-2xl hover:shadow-primary/40 transition-all duration-500 hover:scale-110 hover:-translate-y-1 min-w-[250px] animate-slide-in-left"
              data-testid="button-invite-bot-cta"
            >
              🚀 Add Fynex to Your Server
            </Button>
            <Button 
              onClick={handleJoinSupport}
              variant="outline"
              className="px-10 py-5 bg-card border-2 border-primary text-primary font-bold text-xl rounded-xl hover:bg-primary hover:text-white transition-all duration-500 hover:scale-110 hover:-translate-y-1 min-w-[250px] animate-slide-in-right"
              data-testid="button-join-support-cta"
            >
              💬 Get Help & Support
            </Button>
          </div>
          
          <p className="text-muted-foreground mt-8">
            Free to use • Premium features coming soon
          </p>
        </div>
      </div>
    </section>
  );
}
