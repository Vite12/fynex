import { Button } from "@/components/ui/button";
import fynexLogo from "@assets/white-Photoroom-Photoroom_1757495187403.webp";

export default function Header() {
  const handleInviteBot = () => {
    // TODO: Replace with actual Discord bot invite link
    const DISCORD_BOT_INVITE_URL = 'https://discord.com/api/oauth2/authorize?client_id=YOUR_BOT_ID&permissions=YOUR_PERMISSIONS&scope=bot%20applications.commands';
    window.open(DISCORD_BOT_INVITE_URL, '_blank');
  };

  const handleJoinSupport = () => {
    // TODO: Replace with actual Discord support server invite
    const DISCORD_SUPPORT_SERVER_URL = 'https://discord.gg/YOUR_SUPPORT_SERVER';
    window.open(DISCORD_SUPPORT_SERVER_URL, '_blank');
  };

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="fixed top-0 w-full z-50 backdrop-blur-md bg-background/80 border-b border-border">
      <nav className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <img 
              src={fynexLogo} 
              alt="Fynex Logo" 
              className="w-10 h-10 rounded-xl"
              data-testid="logo-header"
            />
            <div>
              <h1 className="text-xl font-bold text-foreground">Fynex</h1>
              <p className="text-xs text-muted-foreground">Discord Bot</p>
            </div>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            <button 
              onClick={() => scrollToSection('features')}
              className="text-muted-foreground hover:text-primary transition-colors"
              data-testid="link-features"
            >
              Features
            </button>
            <button 
              onClick={() => scrollToSection('about')}
              className="text-muted-foreground hover:text-primary transition-colors"
              data-testid="link-about"
            >
              About
            </button>
            <button 
              onClick={() => scrollToSection('support')}
              className="text-muted-foreground hover:text-primary transition-colors"
              data-testid="link-support"
            >
              Support
            </button>
          </div>
          
          <div className="flex items-center space-x-3">
            <Button 
              onClick={handleJoinSupport}
              variant="secondary"
              className="hidden sm:block px-4 py-2 bg-muted text-muted-foreground rounded-lg hover:bg-border transition-all duration-200 hover:scale-105"
              data-testid="button-join-support-header"
            >
              Join Support
            </Button>
            <Button 
              onClick={handleInviteBot}
              className="px-6 py-2 hero-gradient text-white font-semibold rounded-lg hover:shadow-lg hover:shadow-primary/25 transition-all duration-200 hover:scale-105"
              data-testid="button-invite-bot-header"
            >
              Invite Fynex
            </Button>
          </div>
        </div>
      </nav>
    </header>
  );
}
