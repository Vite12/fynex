import { Button } from "@/components/ui/button";
import fynexLogo from "@assets/white-Photoroom-Photoroom_1757495187403.webp";

export default function HeroSection() {
  const handleInviteBot = () => {
    // TODO: Replace with actual Discord bot invite link
    const DISCORD_BOT_INVITE_URL = 'https://discord.com/api/oauth2/authorize?client_id=YOUR_BOT_ID&permissions=YOUR_PERMISSIONS&scope=bot%20applications.commands';
    window.open(DISCORD_BOT_INVITE_URL, '_blank');
  };

  const handleJoinSupport = () => {
    // TODO: Replace with actual Discord support server invite
    const DISCORD_SUPPORT_SERVER_URL = 'https://discord.gg/YOUR_SUPPORT_SERVER';
    window.open(DISCORD_SUPPORT_SERVER_URL, '_blank');
  };

  return (
    <section className="pt-24 pb-20 px-6">
      <div className="container mx-auto text-center">
        <div className="animate-fade-in">
          <div className="mb-8 flex justify-center">
            <div className="relative">
              <img 
                src={fynexLogo} 
                alt="Fynex Logo" 
                className="w-24 h-24 mx-auto rounded-2xl shadow-2xl animate-float"
                data-testid="logo-hero"
              />
              <div className="absolute -inset-2 hero-gradient rounded-2xl opacity-20 blur-xl animate-pulse"></div>
            </div>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent leading-tight">
            Meet Fynex
          </h1>
          
          <p className="text-xl md:text-2xl text-muted-foreground mb-4 max-w-3xl mx-auto">
            The Ultimate Discord Bot for 
            <span className="text-primary font-semibold"> Chat Rewards</span> & 
            <span className="text-secondary font-semibold"> Giveaways</span>
          </p>
          
          <p className="text-lg text-muted-foreground mb-12 max-w-2xl mx-auto">
            Engage your community with automated rewards, exciting giveaways, stickied messages, comprehensive logs, and so much more.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button 
              onClick={handleInviteBot}
              className="px-8 py-4 hero-gradient text-white font-bold text-lg rounded-xl hover:shadow-xl hover:shadow-primary/30 transition-all duration-300 hover:scale-105 min-w-[200px]"
              data-testid="button-invite-bot-hero"
            >
              🚀 Invite Fynex Now
            </Button>
            <Button 
              onClick={handleJoinSupport}
              variant="outline"
              className="px-8 py-4 bg-card border border-border text-card-foreground font-semibold text-lg rounded-xl hover:bg-muted transition-all duration-300 hover:scale-105 min-w-[200px]"
              data-testid="button-join-support-hero"
            >
              💬 Join Support Server
            </Button>
          </div>
          
          <div className="mt-16 text-center">
            <p className="text-muted-foreground mb-4">Your new favorite Discord bot</p>
            <div className="flex justify-center items-center space-x-8">
              <div className="flex items-center space-x-3 bg-card/50 px-6 py-3 rounded-full border border-border">
                <span className="text-accent text-2xl animate-bounce">✨</span>
                <span className="text-muted-foreground">Free to use</span>
              </div>
              <div className="flex items-center space-x-3 bg-card/50 px-6 py-3 rounded-full border border-border">
                <span className="text-primary text-2xl animate-pulse">🚀</span>
                <span className="text-muted-foreground">Easy setup</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
