import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";

export default function Terms() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-background text-foreground gradient-bg">
      <div className="container mx-auto px-6 py-12">
        <Button 
          onClick={() => setLocation("/")}
          variant="ghost" 
          className="mb-8 text-muted-foreground hover:text-primary"
          data-testid="button-back-home"
        >
          ← Back to Home
        </Button>
        
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold mb-8 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Terms of Service
          </h1>
          
          <div className="max-w-none text-muted-foreground space-y-8">
            <div className="bg-card border border-border rounded-xl p-8">
              <h2 className="text-2xl font-semibold text-card-foreground mb-4">1. Acceptance of Terms</h2>
              <p className="text-muted-foreground">
                By inviting Fynex to your Discord server or using any of its features, you agree to be bound by these Terms of Service. 
                If you do not agree to these terms, please do not use Fynex.
              </p>
            </div>

            <div className="bg-card border border-border rounded-xl p-8">
              <h2 className="text-2xl font-semibold text-card-foreground mb-4">2. Description of Service</h2>
              <p className="text-muted-foreground">
                Fynex is a Discord bot that provides chat rewards, giveaway management, moderation tools, and other community engagement features. 
                The service is provided "as is" and we reserve the right to modify or discontinue features at any time.
              </p>
            </div>

            <div className="bg-card border border-border rounded-xl p-8">
              <h2 className="text-2xl font-semibold text-card-foreground mb-4">3. User Responsibilities</h2>
              <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
                <li>You must comply with Discord's Terms of Service and Community Guidelines</li>
                <li>You are responsible for all activities that occur in your server while using Fynex</li>
                <li>You must not use Fynex for illegal activities or to violate any applicable laws</li>
                <li>You must not attempt to exploit, abuse, or disrupt the bot's functionality</li>
              </ul>
            </div>

            <div className="bg-card border border-border rounded-xl p-8">
              <h2 className="text-2xl font-semibold text-card-foreground mb-4">4. Data Collection and Privacy</h2>
              <p className="text-muted-foreground">
                Fynex collects minimal data necessary for functionality, including user IDs, server IDs, and message data for rewards tracking. 
                For detailed information about data handling, please refer to our Privacy Policy.
              </p>
            </div>

            <div className="bg-card border border-border rounded-xl p-8">
              <h2 className="text-2xl font-semibold text-card-foreground mb-4">5. Limitation of Liability</h2>
              <p className="text-muted-foreground">
                Fynex is provided free of charge. We are not liable for any damages, data loss, or issues arising from the use of the bot. 
                Use of Fynex is at your own risk.
              </p>
            </div>

            <div className="bg-card border border-border rounded-xl p-8">
              <h2 className="text-2xl font-semibold text-card-foreground mb-4">6. Termination</h2>
              <p className="text-muted-foreground">
                We reserve the right to terminate or suspend access to Fynex for any user or server that violates these terms or 
                engages in harmful behavior. You may stop using Fynex at any time by removing it from your server.
              </p>
            </div>

            <div className="bg-card border border-border rounded-xl p-8">
              <h2 className="text-2xl font-semibold text-card-foreground mb-4">7. Changes to Terms</h2>
              <p className="text-muted-foreground">
                We may update these Terms of Service from time to time. Continued use of Fynex after changes constitutes acceptance of the new terms. 
                We will make reasonable efforts to notify users of significant changes.
              </p>
            </div>

            <div className="bg-card border border-border rounded-xl p-8">
              <h2 className="text-2xl font-semibold text-card-foreground mb-4">8. Contact Information</h2>
              <p className="text-muted-foreground">
                If you have questions about these Terms of Service, please contact us through our Discord support server.
              </p>
            </div>
          </div>

          <div className="text-center mt-12">
            <p className="text-muted-foreground">Last updated: September 10, 2025</p>
          </div>
        </div>
      </div>
    </div>
  );
}