import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";

export default function Privacy() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-background text-foreground gradient-bg">
      <div className="container mx-auto px-6 py-12">
        <Button 
          onClick={() => setLocation("/")}
          variant="ghost" 
          className="mb-8 text-muted-foreground hover:text-primary"
          data-testid="button-back-home-privacy"
        >
          ← Back to Home
        </Button>
        
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold mb-8 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Privacy Policy
          </h1>
          
          <div className="max-w-none text-muted-foreground space-y-8">
            <div className="bg-card border border-border rounded-xl p-8">
              <h2 className="text-2xl font-semibold text-card-foreground mb-4">1. Information We Collect</h2>
              <p className="mb-4 text-muted-foreground">Fynex collects the following types of data to provide its services:</p>
              <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
                <li><strong className="text-primary">User IDs:</strong> Discord user IDs to track rewards and participation</li>
                <li><strong className="text-primary">Server IDs:</strong> Discord server IDs to maintain server-specific configurations</li>
                <li><strong className="text-primary">Message Data:</strong> Limited message metadata for chat rewards (content is not stored)</li>
                <li><strong className="text-primary">Giveaway Entries:</strong> User participation in giveaways and contests</li>
                <li><strong className="text-primary">Configuration Data:</strong> Server settings and bot configuration preferences</li>
              </ul>
            </div>

            <div className="bg-card border border-border rounded-xl p-8">
              <h2 className="text-2xl font-semibold text-card-foreground mb-4">2. How We Use Your Information</h2>
              <p className="mb-4 text-muted-foreground">The collected data is used exclusively for:</p>
              <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
                <li>Providing chat rewards and tracking user engagement</li>
                <li>Managing giveaways and selecting winners</li>
                <li>Maintaining server-specific bot configurations</li>
                <li>Providing moderation and logging features</li>
                <li>Improving bot functionality and user experience</li>
              </ul>
            </div>

            <div className="bg-card border border-border rounded-xl p-8">
              <h2 className="text-2xl font-semibold text-card-foreground mb-4">3. Data Storage and Security</h2>
              <p className="text-muted-foreground">
                We implement appropriate technical and organizational measures to protect your data against unauthorized access, 
                alteration, disclosure, or destruction. Data is stored securely and access is limited to essential bot operations.
              </p>
            </div>

            <div className="bg-card border border-border rounded-xl p-8">
              <h2 className="text-2xl font-semibold text-card-foreground mb-4">4. Data Sharing</h2>
              <p className="text-muted-foreground">
                We do not sell, trade, or share your personal data with third parties. Data is only used within the scope of 
                providing Fynex's services to your Discord server.
              </p>
            </div>

            <div className="bg-card border border-border rounded-xl p-8">
              <h2 className="text-2xl font-semibold text-card-foreground mb-4">5. Data Retention</h2>
              <p className="text-muted-foreground">
                We retain data only as long as necessary to provide our services. When Fynex is removed from a server, 
                associated data may be retained for a limited period to allow for re-invitation, then permanently deleted.
              </p>
            </div>

            <div className="bg-card border border-border rounded-xl p-8">
              <h2 className="text-2xl font-semibold text-card-foreground mb-4">6. Your Rights</h2>
              <p className="mb-4 text-muted-foreground">You have the right to:</p>
              <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
                <li>Request information about what data we collect about you</li>
                <li>Request deletion of your data by removing Fynex from your server</li>
                <li>Contact us with questions about our data practices</li>
              </ul>
            </div>

            <div className="bg-card border border-border rounded-xl p-8">
              <h2 className="text-2xl font-semibold text-card-foreground mb-4">7. Discord's Privacy Policy</h2>
              <p className="text-muted-foreground">
                Fynex operates within Discord's platform and is subject to Discord's Privacy Policy. 
                Please review Discord's privacy practices as they also apply to your use of Fynex.
              </p>
            </div>

            <div className="bg-card border border-border rounded-xl p-8">
              <h2 className="text-2xl font-semibold text-card-foreground mb-4">8. Changes to This Policy</h2>
              <p className="text-muted-foreground">
                We may update this Privacy Policy from time to time. We will notify users of significant changes through 
                our support server and update the "Last updated" date below.
              </p>
            </div>

            <div className="bg-card border border-border rounded-xl p-8">
              <h2 className="text-2xl font-semibold text-card-foreground mb-4">9. Contact Us</h2>
              <p className="text-muted-foreground">
                If you have questions about this Privacy Policy or want to exercise your data rights, 
                please contact us through our Discord support server.
              </p>
            </div>
          </div>

          <div className="text-center mt-12">
            <p className="text-muted-foreground">Last updated: September 10, 2025</p>
          </div>
        </div>
      </div>
    </div>
  );
}